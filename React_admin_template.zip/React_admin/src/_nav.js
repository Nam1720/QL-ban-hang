export default {
  items: [
    {
      name: 'Tổng quan',
      url: '/',
      icon: 'icon-home',
      children: []
    },
  ],
};

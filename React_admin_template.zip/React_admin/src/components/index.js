export {default as CustomImage} from 'components/CustomImage'
export {default as Editor} from 'components/Editor'
export {default as CustomBreadcrumb} from 'components/CustomBreadcrumb'
export {default as FooterButton} from 'components/FooterButton'
export {default as ModalConfirm} from 'components/ModalConfirm'
export {default as InputNumber} from 'components/InputNumber'


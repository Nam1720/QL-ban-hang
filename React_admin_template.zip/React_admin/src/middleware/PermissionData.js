export default {
  dashboard: {
    views: {
      url: '/',
      method: 'GET'
    }
  }
};
